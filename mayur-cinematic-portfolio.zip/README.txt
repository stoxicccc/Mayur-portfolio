MAYUR VERMA — CINEMATIC PORTFOLIO

Open index.html to preview. The opening portrait is intentionally an image slot until Mayur supplies the exact photo.

PORTRAIT:
1. Use a transparent PNG cutout of your own photo.
2. Name it exactly: portrait-cutout.png
3. Put it in the same folder as index.html.

Before publishing, replace the email link with your real email and replace project title-card placeholders with real video thumbnails/links. Confirm all experience and skill claims are accurate.

Static site; can be hosted on GitHub Pages free.
